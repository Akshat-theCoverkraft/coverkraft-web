import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux'
import { Drawer, Box, Typography, TextField } from "@mui/material";
import Button from "../component/Button";
import CustomInput from '../component/CustomInput';
import icProfileBg from '../Images/ic_profile_bg.png';
import icDefaultProfile from '../Images/ic_default_profile.png';
import editIcon from '../Images/edit-icon.png';
import { getBYIDUsers, updateUser } from '../store/action/action';
import API_URL from '../ServiceModule/Service';
import IMAGE_PATH from '../ServiceModule/imagePath';
import { getAllState } from '../store/action/action';
import GlobalDropdown from './StateDropdown';
import { Card, Grid } from '@material-ui/core';
import family from '../Images/ic_family_member.png'
import about from '../Images/ic_about.png'
import communication from '../Images/ic_communication_pref.png'
import help from '../Images/ic_help.png'
import logout from '../Images/ic_logout.png'
import rightArrow from '../Images/right-arrow.png'
import Family from '../profile/Family';
import Communication from '../profile/Communication';
import Help from '../profile/Help';
import About from '../profile/About';
import { useNavigate } from 'react-router-dom';
import CityDropdown from './CityDropdown';
import GlobalDatePicker from './GlobalDatePicker';
import { toast } from 'react-toastify';
const ProfileDrawer = ({ open, onClose, userName }) => {
    const dispatch = useDispatch();
    const [drawerOpen, setDrawerOpen] = useState(false);
    const [communicationDrawerOpen, setCommunicationDrawerOpen] = useState(false);
    const [aboutDrawerOpen, setAboutDrawerOpen] = useState(false);
    const [helpDrawerOpen, setHelpDrawerOpen] = useState(false)
    const userEmail = localStorage.getItem('userEmail');
    const [profileImage, setProfileImage] = useState(icDefaultProfile);
    console.log("profileImage", profileImage)
    const [showImageInput, setShowImageInput] = useState(false);
    const [username, setuserName] = useState();
    const [useremail, setuserEmail] = useState();
    const [userDob, setuserDob] = useState();
    const [userAddress, setuserAddress] = useState();
    const [state, setstate] = useState('');
    console.log("state", state);
    const [city, setCity] = useState('')
    console.log('city', city)
    const [userPhone, setuserPhone] = useState();
    const [pinCode, setpinCode] = useState();
    const [gender, setgender] = useState();
    const [userImgFile, setuserImgFile] = useState(null);
    console.log("userImgFile", userImgFile)
    const userbyId = useSelector((state) => state.user);
    const states = useSelector((state) => state.user);
    const [update, setUpdate] = useState(false);
    const navigate = useNavigate();
    const [selectedStateId, setSelectedStateId] = useState('');
    const [selectedCityId, setSelectedCityId] = useState('');
    const [isValidPinCode, setIsValidPinCode] = useState(true);
    const [valid, setValid] = useState(true);
    const [isValidEmail, setIsValidEmail] = useState(true);

    const handleCitySelect = (cityId) => {
        setSelectedCityId(cityId);
    };
    //useeffect
    useEffect(() => {
        dispatch(getAllState(API_URL));
    }, [dispatch]);

    useEffect(() => {
        if (states !== null && states !== undefined) {
            if (states.getAllState !== null && states.getAllState !== undefined) {
                if (states.getAllState.data !== null && states.getAllState.data !== undefined) {
                    setstate(states.getAllState.data)
                }
            }
        }

    }, [states])

    useEffect(() => {
        const userId = localStorage.getItem("userId");
        dispatch(getBYIDUsers(API_URL, userId));
    }, [dispatch]);


    useEffect(() => {
        if (userbyId.getUserById && userbyId.getUserById.data) {
            const data = userbyId.getUserById.data;
            console.log("data", data)
            setuserName(data.userName);
            setuserEmail(data.userEmail);
            setuserPhone(data.userPhone);
            setuserDob(data.userDob);
            setuserAddress(data.userAddress);
            setstate(data.state === null ? null : data.state._id);
            setCity(data.city === null ? null : data.city._id);
            setpinCode(data.pinCode);
            setgender(data.gender);
            setProfileImage(data.userImg ? IMAGE_PATH + data.userImg : icDefaultProfile);

        }
    }, [userbyId]);
console.log('userimg kya h',profileImage)
    const handleStateSelect = (stateId) => {
        setSelectedStateId(stateId);
    };
    //function to check user is above 18 or not
    const isOldEnough = (dob) => {
        const today = new Date(); // Get today's date
        const birthDate = new Date(dob); // Convert dob to a Date object
        let age = today.getFullYear() - birthDate.getFullYear(); // Calculate age

        // Calculate the month difference
        const monthDifference = today.getMonth() - birthDate.getMonth();

        // If the birth month hasn't occurred yet this year, or it's the birth month but the birth day hasn't occurred yet, subtract one year from age
        if (monthDifference < 0 || (monthDifference === 0 && today.getDate() < birthDate.getDate())) {
            age--;
        }

        // Return true if age is 18 or older
        return age >= 18;
    };

    function handleUpateProfile() {

        const formData = new FormData();
        console.log("FormData values before appending:", formData);

        formData.append("_id", localStorage.getItem("userId"));
        formData.append("userName", username);
        formData.append("userEmail", useremail);
        formData.append("userPhone", userPhone);
        formData.append("userDob", userDob);
        formData.append("userAddress", userAddress);
        formData.append("state", selectedStateId);
        formData.append('city', selectedCityId)
        formData.append("pinCode", pinCode);
        formData.append("gender", gender);
        if (userImgFile) {
            formData.append("userImg", userImgFile); // Append the file here
        }
        if (
            username ||
            useremail ||
            userPhone ||
            userDob ||
            userAddress ||
            state ||
            city ||
            pinCode ||
            gender ||
            userImgFile
        ) {
            if (!isOldEnough(userDob)) {
                toast.error('You must be at least 18 years old to register.', {
                    position: "top-center",
                    autoClose: 5000,
                    hideProgressBar: false,
                    closeOnClick: true,
                    pauseOnHover: true,
                    draggable: true,
                });
                return;
            }

            dispatch(updateUser(API_URL, formData))
            .then(()=>{
                toast.success('Updated successfully')
            }).catch((error)=>{
                toast.error('Error in updating')
            })
            onClose();
        } else {
            console.log("No fields are being updated");
        }

    }

    const handleImageChange = (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setProfileImage(reader.result);
                setuserImgFile(file);
            };
            reader.readAsDataURL(file);
        }
    };


    const toggleImageInput = () => {
        setShowImageInput(!showImageInput);
    };

    const handleEdit = () => {
        setUpdate(!update);
    }

    const handleFamilyClose = () => {
        setDrawerOpen(false);

    }
    const handleCommunicationclose = () => {
        setCommunicationDrawerOpen(false);

    }
    const handleHelpclose = () => {
        setHelpDrawerOpen(false);

    }
    const handleAboutClose = () => {
        setAboutDrawerOpen(false);

    }
    const handleFamilyOpen = () => {
        setDrawerOpen(true);
    };
    const handleCommunicationOpen = () => {
        setCommunicationDrawerOpen(true);
    };
    const handleAboutOpen = () => {
        // setAboutDrawerOpen(true);
        onClose();
        navigate('/coverkraft/about')
    };
    const handleHelpOpen = () => {
        setHelpDrawerOpen(true);
    };
    const handleLogout = () => {
        localStorage.removeItem('loggedIn');
        localStorage.removeItem('verificationId');
        localStorage.removeItem('userId');
        localStorage.removeItem('policyId')
        navigate('/coverkraft');
    };
    const handlePinCodeChange = (e) => {
        const pin = e.target.value;
        setpinCode(pin);
        setIsValidPinCode(validatePinCode(pin));
    };
    const validatePinCode = (pin) => {
        // Simple pin code validation (assuming 5 or 6 digit pin codes)
        return /^\d{5,6}$/.test(pin);
    };
    //function to handle email input field start
    const handleEmailChange = (e) => {
        const emailId = e.target.value;
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const isValid = emailRegex.test(useremail);
        setuserEmail(emailId);
        setIsValidEmail(isValid);
    };
    //function to handle email input field start
    //function to handle phone number input field start
    const handlephonechange = (e) => {
        let number = e.target.value.replace(/\D/g, '');
        number = number.slice(0, 10);
        setuserPhone(number);
        const isValid = /^\d{10}$/.test(number.replace('+91', ''));
        setValid(isValid);
    }
    //function to handle phone number input field end
    const handleDobChange = (date) => {
        setuserDob(date);
    };



    return (
        <Drawer anchor="right" open={open} onClose={onClose} className='' >
            <Box sx={{ width: 550, padding: 0, overflowX: 'hidden' }} role="presentation" className=''>
                <div className="main-container">
                    <div className="background-image-container" style={{ backgroundImage: `url(${icProfileBg})`, height: "39vh" }}>
                        <div className="profile-details">

                            <div className="profile-image-container">
                                <img
                                    src={profileImage}
                                    alt="Profile"
                                    className="profile-image"
                                />
                                {update && (
                                    <label htmlFor="profile-image-upload">
                                        <img
                                            src={editIcon}
                                            alt="Edit"
                                            className="edit-icon"
                                            onClick={toggleImageInput}
                                        />
                                    </label>
                                )}
                                {showImageInput && (
                                    <input
                                        id="profile-image-upload"
                                        type="file"
                                        accept="image/*"
                                        onChange={handleImageChange}
                                        style={{ display: "none" }}
                                    />
                                )}

                            </div>


                            <div className="spacer" />
                            <h2 className="text-header">{username}</h2>
                            <div className="spacer-small" />
                            <p className="register-text">{useremail}</p>
                            <div class="text-center text-lg-start ">
                                <Button
                                    text={!update ? 'Edit Profile' : 'View'}
                                    size="sm"
                                    block={true}
                                    onClick={handleEdit}
                                />
                            </div>
                        </div>

                    </div>


                </div>
                {!update ? (
                    <Card className='main-container m-4 p-4'>
                        <Grid container xs={12} spacing={4} className='border-bottom mb-4' onClick={handleFamilyOpen}>
                            <Grid item xs={1}><img src={family} /></Grid>
                            <Grid item xs={10}>Family member</Grid>
                            <Grid item xs={1}><img src={rightArrow} /></Grid>
                        </Grid>
                        <Grid container xs={12} spacing={4} className='border-bottom mb-4' onClick={handleCommunicationOpen}>
                            <Grid item xs={1}><img src={communication} /></Grid>
                            <Grid item xs={10}>Communication preferances </Grid>
                            <Grid item xs={1}><img src={rightArrow} /></Grid>
                        </Grid>
                        <Grid container xs={12} spacing={4} className='border-bottom mb-4' onClick={handleHelpOpen}>
                            <Grid item xs={1}><img src={help} /></Grid>
                            <Grid item xs={10}>Help</Grid>
                            <Grid item xs={1}><img src={rightArrow} /></Grid>
                        </Grid>
                        <Grid container xs={12} spacing={4} className='border-bottom mb-4' onClick={handleAboutOpen}>
                            <Grid item xs={1}><img src={about} /></Grid>
                            <Grid item xs={10}>About</Grid>
                            <Grid item xs={1}><img src={rightArrow} /></Grid>
                        </Grid>
                        <Grid container xs={12} spacing={4} className='border-bottom mb-4' onClick={handleLogout}>
                            <Grid item xs={1}><img src={logout} /></Grid>
                            <Grid item xs={10}>Logout</Grid>
                            <Grid item xs={1}><img src={rightArrow} /></Grid>
                        </Grid>
                    </Card>
                ) : (
                    <div className="main-container mt-4 p-4">
                        <Grid container spacing={4} xs={12} >
                            <Grid item xs={6}>
                                <CustomInput
                                    label="UserName"
                                    placeholder="Enter your UserName"
                                    value={username}
                                    onChange={(e) => setuserName(e.target.value)}
                                    required
                                />

                            </Grid>
                            <Grid item xs={6}>
                                <CustomInput
                                    type="email"
                                    label="Email Address"
                                    value={useremail}
                                    onChange={handleEmailChange}
                                    placeholder="Enter your email address "
                                    className={!isValidEmail ? 'is-invalid' : ''}
                                    validationMessage={!isValidEmail ? 'Please enter a valid email address containing @.' : ''}
                                    style={{ width: '48%' }}
                                />
                            </Grid>
                        </Grid>
                        <div className='col-12' >

                            <CustomInput
                                type="number"
                                label="Mobile Number"
                                value={userPhone}
                                onChange={handlephonechange}
                                placeholder="Enter your mobile number"
                                className={!valid ? 'is-invalid' : ''}
                                validationMessage={!valid ? ' Please enter a valid 10-digit mobile number.' : ''}
                                required
                                style={{ width: '88%' }}

                            />

                        </div>
                        {/* <Grid item xs={6}>
                                <CustomInput
                                    label="UserDOB"
                                    placeholder="Enter your UserDOB"
                                    value={userDob}
                                    onChange={(e) => setuserDob(e.target.value)}
                                />
                            </Grid> */}
                        <div className='col-12 mb-3'>
                            <GlobalDatePicker
                                label="Date"
                                selectedDate={userDob}
                                handleDateChange={handleDobChange}
                                className='custom-picker form-control-lg rounded-5 '
                                placeholder="select Date"

                            />
                        </div>


                        <div className="col-12">
                            <CustomInput
                                label="UserAddress"
                                placeholder="Enter your UserAddress"
                                value={userAddress}
                                onChange={(e) => setuserAddress(e.target.value)}
                            />

                        </div>

                        {/* {states.getAllState && states.getAllState.data && (
                                    <GlobalDropdown
                                        label="State"
                                        value={state}
                                        onChange={(e) => setstate(e.target.value)}
                                        options={states.getAllState.data.map(state => ({ value: state._id, label: state.stateNameEnglish }))}

                                    />
                                )} */}
                        <Grid container spacing={3}>
                            <Grid item xs={12} md={6}>

                                <GlobalDropdown onStateSelect={handleStateSelect} initialValue={state} />

                            </Grid>
                            <Grid item xs={12} md={6}>

                                <CityDropdown selectedStateId={selectedStateId} onCitySelect={handleCitySelect} initialValue={city} />

                            </Grid>
                        </Grid>



                        <Grid container xs={12} spacing={4}>
                            <Grid item xs={6}>
                                <CustomInput
                                    label="PinCode"
                                    placeholder="Enter your PinCode"
                                    value={pinCode}
                                    onChange={(e) => setpinCode(e.target.value)}
                                />

                            </Grid>
                            <Grid item xs={6}>
                                <CustomInput
                                    label="Gender"
                                    placeholder="Enter your gender"
                                    value={gender}
                                    onChange={(e) => setgender(e.target.value)}

                                />
                            </Grid>
                        </Grid>

                        <div className="spacer-small" />
                        <Button size='sm' text="Update" onClick={handleUpateProfile} />
                    </div>
                )}
            </Box>
            <Family family={drawerOpen} onfamilyclose={handleFamilyClose} />
            <Communication communication={communicationDrawerOpen} onCommunicationClose={handleCommunicationclose} />
            <Help help={helpDrawerOpen} onHelpClose={handleHelpclose} />
            {/* <About about={aboutDrawerOpen} onAboutclose={handleAboutClose} /> */}
        </Drawer>
    );
};

export default ProfileDrawer;
